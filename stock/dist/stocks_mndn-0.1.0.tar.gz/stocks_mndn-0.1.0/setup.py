from setuptools import setup, find_packages

setup(
    name='stocks_mndn',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
    ],
    author='mndn',
    author_email='mndn-tab@example.com',
    description='This is a short description of stocks project',
    long_description='This is a longer description of stocks project.',
    long_description_content_type='text/markdown',
    url='https://github.com/mndn-tab/Stocks',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.7',
)
