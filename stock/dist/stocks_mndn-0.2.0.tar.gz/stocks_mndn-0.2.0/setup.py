"""how to publish package to pypi

### Original file is located at
    https://colab.research.google.com/drive/1RxCT59KNh6ldm2fVl4WN16vEdBkI1T0E

### source: ArjanCodes https://www.youtube.com/watch?v=5KEObONUkik

project explaination:
create virtual environment,
in "Python Environment" tab, click "open in power shell"
>>> pip install setuptools, twine, wheel (use powershell in the virtual env folder)
>>> python setup.py bdist_wheel sdist (use powershell in the root folder to create distributions, cause setup.py is in root folder)
>>> twine check dist/* (check the integrity of those distributions.) 
>>> twine upload -r testpypi dist/* (upload it to test.pypi.org)
"""
from setuptools import setup, find_packages

setup(
    name='stocks_mndn',
    version='0.2.0',
    packages=find_packages(),
    install_requires=[
    ],
    author='mndn',
    author_email='mndn-tab@gmail.com',
    description='This is a short description of stocks project',
    long_description='This is a longer description of stocks project.',
    long_description_content_type='text/markdown',
    url='https://github.com/mndn-tab/Stocks',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.7',
)
